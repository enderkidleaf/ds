# 中国城市财政赤字分析

## PA班第二小组第一次小组作业
- **组长**：刘婧 
- **组员**：林慧敏 梁素珍 胡佳 王佳孟 陈桦茜

## 1. 数据来源
- **数据源平台**：国家统计局
- **数据链接**：https://data.stats.gov.cn/easyquery.htm?cn=E0105
- **原始数据文件**（存放于 `data_raw/` 文件夹）：
  - `city_income.xlsx`：地方一般公共预算收入
  - `city_expenditure.xlsx`：地方一般公共预算支出
  - `gdp.xlsx`：地区生产总值（当年价格）
  - `individual_deposit.xlsx`：住户存款余额
  - `real_estate_invest.xlsx`：房地产开发投资额
  - `house_sales_area.xlsx`：商品房销售面积
- **时间范围**：2006–2026 年
- **数据清洗规则**：
  1.  跳过前 3 行无用表头信息
  2.  过滤表尾备注行（包含“注”“数据来源”字样的行）
  3.  将宽表（年份为列）转换为长表格式，字段为 `city`（城市）、`year`（年份）、`value`（指标值）
  4.  提取年份中的纯数字，转换为整数类型

## 2. 项目结构
城市财政赤字分析 /
├── data_raw/ # 原始 Excel 数据（从国家统计局下载）
├── data_clean/ # 清洗后可直接分析的 CSV 数据
│ ├── city_finance_data.csv # 基础财政 + GDP 数据
│ ├── city_finance_analysis_data.csv # 含增长率的中间分析数据
│ └── city_finance_final_data.csv # 最终完整数据（含房地产指标）
├── output/ # 可视化图表与分析结果
│ ├── bgsg_gap_to_gdp.png # 北上广深 gap_to_gdp 时序对比
│ ├── prd_vs_yrd_gap_to_gdp.png # 珠三角 vs 长三角 gap_to_gdp 对比
│ ├── real_estate_invest_vs_gap.png # 房地产投资 vs gap_to_gdp 散点图
│ └── bgsg_real_estate_time_series.png # 北上广深房地产投资时序对比
├── README.md # 项目说明文档
└── analysis.ipynb # 完整分析代码（Python）

## 3. 分析任务
### 3.1 核心指标计算
- **预算缺口**：`gap = 预算支出 - 预算收入`
- **缺口占 GDP 比重**：`gap_to_gdp = gap / gdp`
- **年度增长率**：
  - `income_growth`：财政收入年度增长率
  - `expend_growth`：财政支出年度增长率

### 3.2 区域分组说明
本研究结合中国城市群发展规划，**手动对样本城市进行区域分组**（无需额外下载城市数据）：
- **珠三角城市群**：广州、深圳、珠海、佛山、东莞、中山、惠州
- **长三角城市群**：上海、南京、杭州、宁波、苏州、无锡、常州
该分组用于对比分析两大经济圈的财政收支平衡差异。

### 3.3 关键分析内容
1.  筛选 2006、2010、2014、2018、2022 年度 `gap_to_gdp` 最大和最小的城市
2.  北上广深四个城市 `gap_to_gdp` 时序对比分析
3.  珠三角与长三角城市 `gap_to_gdp` 平均水平对比分析
4.  从房地产开发投资与商品房销售角度，分析 `gap_to_gdp` 的地区差异与时序特征

## 4. 代码运行说明
- **分析语言**：Python
- **核心依赖库**：`pandas`（数据处理）、`matplotlib`（可视化）
- **运行流程**：
  1.  读取并清洗所有原始 Excel 数据
  2.  合并为完整数据集，计算核心分析指标
  3.  筛选特定年份极值城市
  4.  基于区域分组计算珠三角/长三角平均 `gap_to_gdp`
  5.  生成可视化图表并保存至 `output/` 文件夹

## 5. 其他说明
- 本作业为小组独立完成，所有代码与分析均为原创
- 分析过程中使用 AI 工具辅助，提示词链接：[https://www.doubao.com/thread/w3e8128a3f37b6e4d]