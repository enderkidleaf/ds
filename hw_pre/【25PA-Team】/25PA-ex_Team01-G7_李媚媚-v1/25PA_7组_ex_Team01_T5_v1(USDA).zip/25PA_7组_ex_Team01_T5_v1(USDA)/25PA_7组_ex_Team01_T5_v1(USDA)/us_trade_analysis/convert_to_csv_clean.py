import pandas as pd
import os

print("开始处理数据...")

# 读取Excel文件
import_file = 'data_raw/us_import_cleaned.xlsx'  # 调整好格式的原始文件
export_file = 'data_raw/us_export_cleaned.xlsx'

# 转换为CSV
print("正在转换进口数据...")
df_import = pd.read_excel(import_file)
df_import.to_csv('data_raw/us_import_cleaned.csv', index=False, encoding='utf-8-sig')
print("✅ 进口数据转换完成：data_raw/us_import_cleaned.csv")

print("正在转换出口数据...")
df_export = pd.read_excel(export_file)
df_export.to_csv('data_raw/us_export_cleaned.csv', index=False, encoding='utf-8-sig')
print("✅ 出口数据转换完成：data_raw/us_export_cleaned.csv")

print("\n所有转换完成！")