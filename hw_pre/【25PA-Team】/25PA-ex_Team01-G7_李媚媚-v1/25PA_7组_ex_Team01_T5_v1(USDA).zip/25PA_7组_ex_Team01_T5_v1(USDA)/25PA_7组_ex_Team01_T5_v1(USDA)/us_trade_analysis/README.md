## 美国Top25农业商品进出口分析

> **课程**：数据分析与经济决策 | **学期**：2026年春季  
> **25MDE PA 第 7 组**

---

## 👥 小组成员

| 序号 | 姓名 |
|:----:|:----:|
| 1 | 李媚媚 |
| 2 | 竹泳霏 |
| 3 | 沈丽 |
| 4 | 欧乐锋 |
| 5 | 赵珏 |
| 6 | 林志远 |

---

## 📁 目录结构


us_trade_analysis
|
|
|   analysis.ipynb
|   analysis_v0.ipynb
|   convert_to_csv_clean.py
|   directory_structure.txt
|   download_data.py
|   README.md
|   
+---data_clean
|       us_export_clean.csv
|       us_import_clean.csv
|       
+---data_raw
|       us_export.csv
|       us_export.xlsx
|       us_export_cleaned.csv
|       us_export_cleaned.xlsx
|       us_import.csv
|       us_import.xlsx
|       us_import_cleaned.csv
|       us_import_cleaned.xlsx
|       
|---output
        commodity_barchart.png
        processing_level_master.png
        risk_analysis_master.png
        trend_chart_master.png
        

## 📈 分析内容
1. **数据清洗**：数据本身无缺失值，但是从.xlsx转成.csv的时候需要留意表格的结构
2. **趋势分析**：1991-2024年进出口变化趋势
3. **商品分析**：主要进出口加工程度类别分析
4. **结构分析**：进出口比例关系

## 🎨 生成图表
| 图表名称 | 文件名 | 说明 |
|---------|--------|------|
| 趋势图 | `trend_chart_master.png` | 进出口随时间变化趋势 |
| 柱状图 | `commodity_barchart.png` | 主要商品进出口额对比 |
| 饼图 | `processing_level_master.png` | 加工层次分析 |
| 饼图 | `risk_analysis_master.png` | 贸易集中度风险分析 |

## 🔍 主要发现

### 1. 总体贸易格局
- 📦 分析期间总进口额：XX 十亿美元
- 📤 分析期间总出口额：XX 十亿美元
- ⚖️ 贸易差额：XX 十亿美元（逆差/顺差）

### 2. 时间趋势特征
- 📈 进口峰值出现在 XXXX 年
- 📉 出口最低点在 XXXX 年
- 🚀 增长最快时期：XXXX-XXXX 年

### 3. 商品结构特点
- 🏆 最大进口商品：XXXX
- 🥇 最大出口商品：XXXX
- 📊 前5大商品占总贸易额 XX%


## 🛠️ 运行方法
1. 安装依赖：`pip install pandas matplotlib seaborn jupyter openpyxl`
2. 运行下载脚本：`python download_data.py`
3. 打开分析文件：`jupyter notebook analysis.ipynb`

## 📅 数据来源
- 美国贸易统计局 (U.S. Census Bureau)
- 数据时间范围：1991-2024年

## 👥 AI Assitant
[DeepSeek]https://chat.deepseek.com/share/ybt5po87qrg2krx8hr

## 📌 最后更新
2026年 [Mar.19th]