import requests
import os

print("开始下载数据...")

# 下载函数
def download_data(url, filename):
    print(f"正在下载: {filename}")
    try:
        response = requests.get(url)
        with open(f"data_raw/{filename}", "wb") as f:
            f.write(response.content)
        print(f"✅ 下载完成: {filename}")
    except Exception as e:
        print(f"❌ 下载失败: {filename}")
        print(f"错误信息: {e}")

# 下载数据
download_data(
    "https://ers.usda.gov/sites/default/files/_laserfiche/DataFiles/50441/fytop25hvpexp.xlsx?v=33751",
    "us_export.xlsx"
)
download_data(
    "https://ers.usda.gov/sites/default/files/_laserfiche/DataFiles/50441/fytop25hvpimp.xlsx?v=90386",
    "us_import.xlsx"
)

print("\n所有数据下载完成！文件保存在 data_raw 文件夹")

import pandas as pd
import os

print("开始处理数据...")

# 读取Excel文件
import_file = 'data_raw/us_import.xlsx'  # 你下载的原始文件
export_file = 'data_raw/us_export.xlsx'

# 转换为CSV
print("正在转换进口数据...")
df_import = pd.read_excel(import_file)
df_import.to_csv('data_raw/us_import.csv', index=False, encoding='utf-8-sig')
print("✅ 进口数据转换完成：data_raw/us_import.csv")

print("正在转换出口数据...")
df_export = pd.read_excel(export_file)
df_export.to_csv('data_raw/us_export.csv', index=False, encoding='utf-8-sig')
print("✅ 出口数据转换完成：data_raw/us_export.csv")

print("\n所有转换完成！")