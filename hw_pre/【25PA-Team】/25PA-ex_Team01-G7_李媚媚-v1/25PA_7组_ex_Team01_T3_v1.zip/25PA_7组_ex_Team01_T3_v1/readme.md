# 📊 中国A股上市公司数量与行业分布分析

> **课程**：数据分析与经济决策 | **学期**：2026年春季  
> **25MDE PA 第 7 组**

---

## 👥 小组成员

| 序号 | 姓名 |
|:----:|:----:|
| 1 | 李媚媚 |
| 2 | 竹泳霏 |
| 3 | 沈丽 |
| 4 | 欧乐锋 |
| 5 | 赵珏 |
| 6 | 林志远 |

---

## 📁 目录结构

```
项目根目录/
│
├── China_stock_analysis.ipynb   ← 主分析 Notebook（本文件）
├── readme.md                    ← 项目说明（本文件）
│
├── data_raw/                    ← 原始数据（自动生成）
│   ├── sz_listed_companies_raw.csv   深交所原始上市公司列表
│   ├── sh_listed_companies_raw.csv   上交所原始上市公司列表
│   └── bj_listed_companies_raw.csv   北交所原始上市公司列表
│
├── data_clean/                  ← 清洗后数据（自动生成）
│   └── all_listed_companies.csv      三交所合并清洗数据
│
├── output/                      ← 图表输出（自动生成）
│   ├── fig1_annual_new_companies.png      各年度新增上市公司数量（堆叠柱状图）
│   ├── fig2_cumulative_companies.png      历年累计上市公司数量（折线图）
│   ├── fig_sz_board_annual.png            深交所各板块历年新增（堆叠柱状图）
│   ├── fig_sh_board_annual.png            上交所各板块历年新增（堆叠柱状图）
│   ├── fig3_industry_by_exchange_2024.png 2024年各交易所行业分布TOP10（条形图）
│   └── fig4_industry_pie_2024.png         2024年各交易所行业分布（饼图）
│
└── doc/                         ← Word报告输出（自动生成）
    └── China_Stock_Analysis_Report.docx
```

---

## 🚀 快速运行说明

### 环境要求

- Python 3.8+
- Jupyter Notebook / JupyterLab / VS Code (Jupyter插件)

### 安装依赖

```bash
pip install akshare pandas numpy matplotlib seaborn openpyxl python-docx pillow
```

> **注意**：首次运行请先取消注释 Cell1 顶部的 `!pip install ...` 命令。

### 运行顺序

按顺序依次运行所有单元格（**Cell1 → Cell8**），或点击菜单 **Kernel → Restart & Run All**。

| 单元格 | 功能 | 预计耗时 |
|:------:|------|:--------:|
| Cell 1 | 环境准备、导入库、创建目录 | < 5秒 |
| Cell 2 | 深交所数据获取 | 10~30秒 |
| Cell 3 | 上交所数据获取 | 10~30秒 |
| **Cell 4** | **行业分类补充（三重保障）** | **2~5分钟** |
| Cell 5 | 北交所数据获取 | 30~60秒 |
| Cell 6 | 数据清洗与整合 | < 10秒 |
| Cell 7 | 历年数量统计与可视化（图1~4） | 10~30秒 |
| Cell 8 | 2024年行业分布分析（图5~6） | 10~30秒 |
| Cell 9 | 生成Word报告 | 5~15秒 |

---

## 📈 分析内容

本项目分析 **沪、深、北三大交易所** A股上市公司，涵盖以下维度：

### 一、历年上市公司数量统计
- 各年度新增上市公司数量（按交易所分色堆叠柱状图）
- 历年累计上市公司数量（折线面积图）
- 深圳交易所各板块细分（主板 / 中小板 / 创业板）
- 上海交易所各板块细分（主板 / 科创板）

### 二、2024年行业分布分析
- 三大交易所分别展示行业 TOP10（横向条形图）
- 三大交易所行业分布饼图（图例置于右侧，无内部文字重叠）

---

## 🔧 常见问题（FAQ）

**Q1：Cell 4 运行很慢，正常吗？**  
A：正常。Cell 4 会依次尝试三种方案获取行业数据：东方财富API → 乐咕乐股 → 直接HTTP请求，预计耗时 2~5 分钟。只要看到进度输出（如 `[10/102] 已映射：1234 家`）就是正在正常运行。

**Q2：上交所行业分布显示"行业数据暂缺"怎么办？**  
A：请确认 Cell 4 已成功运行且 `industry_map 大小 > 2000 条`。若三种方案均失败，请：
1. 检查网络是否能访问 `eastmoney.com` 和 `legulegu.com`
2. 关闭 VPN 后重试（VPN 可能屏蔽国内 API）
3. 运行 `pip install --upgrade akshare` 更新库

**Q3：运行时出现 `ModuleNotFoundError`？**  
A：请运行 Cell 1 顶部被注释的 `!pip install ...` 命令安装依赖包。

**Q4：图表中文显示为方块？**  
A：Cell 1 会自动检测并配置系统中文字体（Windows 优先使用微软雅黑，macOS 使用 PingFang SC，Linux 使用 WenQuanYi）。若仍有乱码，请手动安装中文字体后重启 Jupyter。

**Q5：`bj_df is not defined` 错误？**  
A：请勿单独运行 Cell 6（数据整合），必须先运行 Cell 5（北交所数据获取）。建议按顺序从头运行。

**Q6：Word报告中图片路径找不到？**  
A：请先完整运行到 Cell 8（图表生成），确保 `output/` 目录下有所有 PNG 图片，再运行 Cell 9 生成报告。

---

## 📦 数据来源

| 数据 | 来源 | 接口 |
|------|------|------|
| 深交所上市公司列表 | 深圳证券交易所 | `ak.stock_info_sz_name_code()` |
| 上交所上市公司列表 | 上海证券交易所 | `ak.stock_info_sh_name_code()` |
| 北交所上市公司列表 | 北京证券交易所官方API | `bse.cn/nqxxController` |
| 行业分类（主方案） | 东方财富行业板块 | `ak.stock_board_industry_name_em()` |
| 行业分类（备用） | 申万一级行业（乐咕乐股） | `legulegu.com/index-composition` |

---

## 📝 版本记录

| 版本 | 日期 | 修改内容 |
|------|------|----------|
| v1.0 | 2026-03-19 | 初始版本，完成三交所数据获取与基础分析 |
| v1.1 | 2026-03-19 | 修复北交所 tqdm 报错、中文乱码问题 |
| v1.2 | 2026-03-19 | 新增行业分类三重保障（东方财富+乐咕乐股+直接HTTP） |
| v1.3 | 2026-03-19 | 修复 bj_df NameError；新增板块细分历年统计 |
| v1.4 | 2026-03-19 | 饼图优化：图例右置、环形设计、消除文字重叠 |

---

*本项目仅供学习使用，数据实时从公开接口获取，不构成任何投资建议。*

## 👥 AI Assitant
[genspark]https://www.genspark.ai/agents?id=d6ea7401-97ea-4693-a1ed-6a28224a8c26