"""生成汇总分析 Excel 文件"""
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.formatting.rule import ColorScaleRule
import os

df = pd.read_csv("data_clean/panel_data.csv")
df_rank = pd.read_csv("data_clean/gap_rank_by_year.csv")

YEARS = list(range(2004, 2023))
CITIES = df["城市"].unique().tolist()

# ── 样式辅助函数 ──
def hdr_fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def thin_border():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

def center_align(wrap=False):
    return Alignment(horizontal="center", vertical="center", wrap_text=wrap)

def right_align():
    return Alignment(horizontal="right", vertical="center")

HDR_FONT  = Font(name="Arial", bold=True, size=10, color="FFFFFF")
BODY_FONT = Font(name="Arial", size=9)
TITLE_FONT= Font(name="Arial", bold=True, size=12)

BLUE_FILL   = hdr_fill("2F5496")
GREEN_FILL  = hdr_fill("375623")
RED_FILL    = hdr_fill("C00000")
ORANGE_FILL = hdr_fill("E26B0A")
LGRAY_FILL  = hdr_fill("F2F2F2")

wb = Workbook()

# ════════════════════════════════════════
# Sheet 1 – 说明页
# ════════════════════════════════════════
ws0 = wb.active
ws0.title = "说明"
ws0.column_dimensions["A"].width = 80
rows_info = [
    ("中国城市财政赤字分析 – 数据汇总报告", TITLE_FONT, "2F5496"),
    ("", None, None),
    ("数据来源", Font(name="Arial", bold=True, size=10), None),
    ("  · 地方一般公共预算收入 / 支出：《中国城市统计年鉴》2005–2023", BODY_FONT, None),
    ("  · 地区生产总值（当年价格）：《中国城市统计年鉴》2005–2023", BODY_FONT, None),
    ("  · 住户存款余额：中国人民银行城市分支数据", BODY_FONT, None),
    ("", None, None),
    ("城市范围：36个主要城市（4个直辖市 + 27个省会城市 + 5个计划单列市）", BODY_FONT, None),
    ("时间跨度：2004–2022年（19年面板数据）", BODY_FONT, None),
    ("", None, None),
    ("工作表说明", Font(name="Arial", bold=True, size=10), None),
    ("  Sheet 2 [面板数据]  – 36城市完整面板（收入、支出、GDP、缺口、缺口率、增长率）", BODY_FONT, None),
    ("  Sheet 3 [缺口率矩阵] – gap_to_gdp 宽表（城市×年份），附条件格式", BODY_FONT, None),
    ("  Sheet 4 [年度极值]  – 各特定年份 gap_to_gdp 最大 / 最小城市", BODY_FONT, None),
    ("  Sheet 5 [北上广深]  – 一线城市财政指标对比", BODY_FONT, None),
    ("  Sheet 6 [城市群对比] – 珠三角 vs 长三角 gap_to_gdp 对比", BODY_FONT, None),
    ("  Sheet 7 [增长率汇总] – 收入 / 支出 / GDP 年均增长率排名", BODY_FONT, None),
]
for r, (text, font, color) in enumerate(rows_info, 1):
    cell = ws0.cell(row=r, column=1, value=text)
    if font:
        cell.font = font
    if color:
        cell.fill = PatternFill("solid", fgColor=color)
    if r == 1:
        cell.alignment = Alignment(horizontal="center", vertical="center")
ws0.row_dimensions[1].height = 28

# ════════════════════════════════════════
# Sheet 2 – 完整面板数据
# ════════════════════════════════════════
ws1 = wb.create_sheet("面板数据")
headers = ["城市", "年份", "预算收入(亿元)", "预算支出(亿元)", "GDP(亿元)",
           "存款余额(亿元)", "财政缺口(亿元)", "缺口/GDP(%)",
           "收入增长率(%)", "支出增长率(%)", "GDP增长率(%)"]
for col, h in enumerate(headers, 1):
    c = ws1.cell(row=1, column=col, value=h)
    c.font = HDR_FONT
    c.fill = BLUE_FILL
    c.alignment = center_align()
    c.border = thin_border()

col_widths = [10, 6, 14, 14, 12, 14, 14, 12, 13, 13, 12]
for i, w in enumerate(col_widths, 1):
    ws1.column_dimensions[get_column_letter(i)].width = w

df_sorted = df.sort_values(["城市", "year"])
for r_idx, row in enumerate(df_sorted.itertuples(index=False), 2):
    fill = LGRAY_FILL if r_idx % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
    vals = [
        row.城市, row.year,
        round(row.income, 1), round(row.expend, 1), round(row.gdp, 1),
        round(row.deposit, 1), round(row.gap, 1),
        round(row.gap_to_gdp * 100, 2),
        round(row.income_growth * 100, 2) if not np.isnan(row.income_growth) else "",
        round(row.expend_growth * 100, 2) if not np.isnan(row.expend_growth) else "",
        round(row.gdp_growth * 100, 2) if not np.isnan(row.gdp_growth) else "",
    ]
    for col, v in enumerate(vals, 1):
        c = ws1.cell(row=r_idx, column=col, value=v)
        c.font = BODY_FONT
        c.fill = fill
        c.border = thin_border()
        if col in [3, 4, 5, 6, 7]:
            c.number_format = "#,##0.0"
        elif col in [8, 9, 10, 11]:
            c.number_format = "0.00"
        if col == 2:
            c.alignment = center_align()

ws1.freeze_panes = "C2"

# ════════════════════════════════════════
# Sheet 3 – 缺口率矩阵（宽表）
# ════════════════════════════════════════
ws2 = wb.create_sheet("缺口率矩阵")
pivot = df.pivot(index="城市", columns="year", values="gap_to_gdp") * 100

# 标题行
ws2.cell(1, 1, "城市").font = HDR_FONT
ws2.cell(1, 1).fill = BLUE_FILL
ws2.cell(1, 1).alignment = center_align()
ws2.column_dimensions["A"].width = 12

for j, yr in enumerate(YEARS, 2):
    c = ws2.cell(1, j, str(yr))
    c.font = HDR_FONT
    c.fill = BLUE_FILL
    c.alignment = center_align()
    ws2.column_dimensions[get_column_letter(j)].width = 8

for i, city in enumerate(CITIES, 2):
    ws2.cell(i, 1, city).font = BODY_FONT
    ws2.cell(i, 1).alignment = center_align()
    for j, yr in enumerate(YEARS, 2):
        val = pivot.loc[city, yr] if city in pivot.index else ""
        c = ws2.cell(i, j, round(float(val), 1) if val != "" else "")
        c.font = BODY_FONT
        c.alignment = center_align()
        c.number_format = "0.0"

# 条件格式（色阶）
from openpyxl.utils import get_column_letter
end_col = get_column_letter(len(YEARS) + 1)
end_row = len(CITIES) + 1
data_range = f"B2:{end_col}{end_row}"
ws2.conditional_formatting.add(
    data_range,
    ColorScaleRule(
        start_type="min", start_color="63BE7B",
        mid_type="percentile", mid_value=50, mid_color="FFEB84",
        end_type="max", end_color="F8696B"
    )
)
ws2.freeze_panes = "B2"

# ════════════════════════════════════════
# Sheet 4 – 年度极值
# ════════════════════════════════════════
ws3 = wb.create_sheet("年度极值")
df_rank_ext = []
for yr in [2006, 2010, 2014, 2018, 2022]:
    sub = df[df["year"] == yr].sort_values("gap_to_gdp", ascending=False)
    top3    = sub.head(3)
    bottom3 = sub.tail(3)
    for rank_i, (_, row) in enumerate(top3.iterrows(), 1):
        df_rank_ext.append({"年份": yr, "类型": "最大(赤字最高)", "排名": rank_i,
                             "城市": row["城市"], "gap_to_gdp(%)": round(row["gap_to_gdp"]*100, 2),
                             "缺口(亿元)": round(row["gap"], 1), "GDP(亿元)": round(row["gdp"], 1)})
    for rank_i, (_, row) in enumerate(bottom3.iterrows(), 1):
        df_rank_ext.append({"年份": yr, "类型": "最小(盈余/低赤字)", "排名": rank_i,
                             "城市": row["城市"], "gap_to_gdp(%)": round(row["gap_to_gdp"]*100, 2),
                             "缺口(亿元)": round(row["gap"], 1), "GDP(亿元)": round(row["gdp"], 1)})
df_re = pd.DataFrame(df_rank_ext)
hdrs3 = list(df_re.columns)
for j, h in enumerate(hdrs3, 1):
    c = ws3.cell(1, j, h)
    c.font = HDR_FONT
    c.fill = GREEN_FILL
    c.alignment = center_align()
for r_i, row in enumerate(df_re.itertuples(index=False), 2):
    row_fill = LGRAY_FILL if r_i % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
    for j, v in enumerate(row, 1):
        c = ws3.cell(r_i, j, v)
        c.font = BODY_FONT
        c.fill = row_fill
        c.alignment = center_align()
        c.border = thin_border()
for j, w in enumerate([7, 16, 6, 10, 14, 12, 12], 1):
    ws3.column_dimensions[get_column_letter(j)].width = w

# ════════════════════════════════════════
# Sheet 5 – 北上广深
# ════════════════════════════════════════
ws4 = wb.create_sheet("北上广深")
TIER1 = ["北京", "上海", "广州", "深圳"]
df_t1 = df[df["城市"].isin(TIER1)].sort_values(["城市", "year"])
hdrs4 = ["城市", "年份", "预算收入(亿元)", "预算支出(亿元)", "GDP(亿元)",
         "财政缺口(亿元)", "缺口/GDP(%)", "收入增长率(%)", "支出增长率(%)"]
fill_map = {"北京": "FF6B6B", "上海": "4ECDC4", "广州": "45B7D1", "深圳": "96CEB4"}
for j, h in enumerate(hdrs4, 1):
    c = ws4.cell(1, j, h)
    c.font = HDR_FONT
    c.fill = RED_FILL
    c.alignment = center_align()
for r_i, row in enumerate(df_t1.itertuples(index=False), 2):
    city_fill = PatternFill("solid", fgColor=fill_map.get(row.城市, "FFFFFF") + "30")
    vals = [row.城市, row.year, round(row.income, 1), round(row.expend, 1),
            round(row.gdp, 1), round(row.gap, 1), round(row.gap_to_gdp*100, 2),
            round(row.income_growth*100, 2) if not np.isnan(row.income_growth) else "",
            round(row.expend_growth*100, 2) if not np.isnan(row.expend_growth) else ""]
    for j, v in enumerate(vals, 1):
        c = ws4.cell(r_i, j, v)
        c.font = BODY_FONT
        c.border = thin_border()
        if j in [3, 4, 5, 6]:
            c.number_format = "#,##0.0"
ws4.freeze_panes = "C2"

# ════════════════════════════════════════
# Sheet 6 – 城市群对比
# ════════════════════════════════════════
ws5 = wb.create_sheet("城市群对比")
PRD = ["广州", "深圳", "珠海", "佛山", "东莞", "中山"]
YRD = ["上海", "南京", "苏州", "杭州", "宁波", "合肥"]
PRD = [c for c in PRD if c in CITIES]
YRD = [c for c in YRD if c in CITIES]

df_prd = df[df["城市"].isin(PRD)].groupby("year").agg(
    gap_to_gdp_mean=("gap_to_gdp", "mean"),
    gap_to_gdp_std=("gap_to_gdp", "std"),
    income_mean=("income", "mean"),
    expend_mean=("expend", "mean"),
    gdp_mean=("gdp", "mean")
).reset_index()
df_yrd = df[df["城市"].isin(YRD)].groupby("year").agg(
    gap_to_gdp_mean=("gap_to_gdp", "mean"),
    gap_to_gdp_std=("gap_to_gdp", "std"),
    income_mean=("income", "mean"),
    expend_mean=("expend", "mean"),
    gdp_mean=("gdp", "mean")
).reset_index()

ws5.cell(1, 1, "珠三角城市群（Pearl River Delta）").font = Font(name="Arial", bold=True, size=11, color="C00000")
ws5.cell(1, 1).alignment = center_align()
ws5.merge_cells("A1:E1")

hdrs5 = ["年份", "gap/GDP均值(%)", "gap/GDP标准差(%)", "收入均值(亿元)", "GDP均值(亿元)"]
for j, h in enumerate(hdrs5, 1):
    c = ws5.cell(2, j, h)
    c.font = HDR_FONT
    c.fill = hdr_fill("C00000")
    c.alignment = center_align()

for r_i, row in enumerate(df_prd.itertuples(index=False), 3):
    vals = [row.year, round(row.gap_to_gdp_mean*100, 2), round(row.gap_to_gdp_std*100, 2),
            round(row.income_mean, 1), round(row.gdp_mean, 1)]
    for j, v in enumerate(vals, 1):
        c = ws5.cell(r_i, j, v)
        c.font = BODY_FONT
        c.border = thin_border()

offset = len(df_prd) + 4
ws5.cell(offset, 1, "长三角城市群（Yangtze River Delta）").font = Font(name="Arial", bold=True, size=11, color="1F497D")
ws5.cell(offset, 1).alignment = center_align()
ws5.merge_cells(f"A{offset}:E{offset}")
for j, h in enumerate(hdrs5, 1):
    c = ws5.cell(offset+1, j, h)
    c.font = HDR_FONT
    c.fill = BLUE_FILL
    c.alignment = center_align()
for r_i, row in enumerate(df_yrd.itertuples(index=False), offset+2):
    vals = [row.year, round(row.gap_to_gdp_mean*100, 2), round(row.gap_to_gdp_std*100, 2),
            round(row.income_mean, 1), round(row.gdp_mean, 1)]
    for j, v in enumerate(vals, 1):
        c = ws5.cell(r_i, j, v)
        c.font = BODY_FONT
        c.border = thin_border()

for j, w in enumerate([7, 14, 16, 14, 14], 1):
    ws5.column_dimensions[get_column_letter(j)].width = w

# ════════════════════════════════════════
# Sheet 7 – 增长率汇总
# ════════════════════════════════════════
ws6 = wb.create_sheet("增长率汇总")
df_city_growth = df.groupby("城市").agg(
    income_cagr=("income_growth", "mean"),
    expend_cagr=("expend_growth", "mean"),
    gdp_cagr=("gdp_growth", "mean")
).dropna().reset_index()
df_city_growth = df_city_growth.sort_values("income_cagr", ascending=False)
df_city_growth["income_cagr"]  = (df_city_growth["income_cagr"] * 100).round(2)
df_city_growth["expend_cagr"]  = (df_city_growth["expend_cagr"] * 100).round(2)
df_city_growth["gdp_cagr"]     = (df_city_growth["gdp_cagr"] * 100).round(2)
df_city_growth["expend_gt_income"] = df_city_growth.apply(
    lambda r: "是" if r["expend_cagr"] > r["income_cagr"] else "否", axis=1)

ws6.cell(1, 1, "36城市 2004–2022 年均复合增长率（CAGR）").font = Font(name="Arial", bold=True, size=12)
ws6.merge_cells("A1:E1")
hdrs6 = ["城市", "收入CAGR(%)", "支出CAGR(%)", "GDP CAGR(%)", "支出增速>收入?"]
for j, h in enumerate(hdrs6, 1):
    c = ws6.cell(2, j, h)
    c.font = HDR_FONT
    c.fill = ORANGE_FILL
    c.alignment = center_align()
for r_i, row in enumerate(df_city_growth.itertuples(index=False), 3):
    bg = PatternFill("solid", fgColor="FFF2CC") if row.expend_cagr > row.income_cagr else PatternFill("solid", fgColor="E2EFDA")
    vals = [row.城市, row.income_cagr, row.expend_cagr, row.gdp_cagr, row.expend_gt_income]
    for j, v in enumerate(vals, 1):
        c = ws6.cell(r_i, j, v)
        c.font = BODY_FONT
        c.fill = bg
        c.border = thin_border()
        c.alignment = center_align()
for j, w in enumerate([10, 12, 12, 12, 14], 1):
    ws6.column_dimensions[get_column_letter(j)].width = w

os.makedirs("output", exist_ok=True)
output_path = "output/中国城市财政赤字分析_汇总报告.xlsx"
wb.save(output_path)
print(f"Excel汇总报告已保存: {output_path}")
