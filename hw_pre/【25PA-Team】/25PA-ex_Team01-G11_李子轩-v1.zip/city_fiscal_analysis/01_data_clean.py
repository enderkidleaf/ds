"""
数据清洗脚本：读取原始数据，整理为长格式，计算关键指标
"""
import pandas as pd
import os

os.makedirs("data_clean", exist_ok=True)

# ---------- 读取原始数据 ----------
df_income  = pd.read_excel("data_raw/city_income.xlsx")
df_expend  = pd.read_excel("data_raw/city_expenditure.xlsx")
df_gdp     = pd.read_excel("data_raw/gdp.xlsx")
df_deposit = pd.read_excel("data_raw/individual_deposit.xlsx")

years = [str(y) for y in range(2004, 2023)]

def to_long(df, value_name):
    long = df.melt(id_vars="城市", value_vars=years, var_name="year", value_name=value_name)
    long["year"] = long["year"].astype(int)
    return long

long_income  = to_long(df_income,  "income")
long_expend  = to_long(df_expend,  "expend")
long_gdp     = to_long(df_gdp,     "gdp")
long_deposit = to_long(df_deposit, "deposit")

# ---------- 合并 ----------
df = long_income.merge(long_expend,  on=["城市", "year"]) \
                .merge(long_gdp,     on=["城市", "year"]) \
                .merge(long_deposit, on=["城市", "year"])

df = df.sort_values(["城市", "year"]).reset_index(drop=True)

# ---------- 计算关键指标 ----------
df["gap"]        = df["expend"] - df["income"]          # 财政缺口（亿元）
df["gap_to_gdp"] = df["gap"] / df["gdp"]                # 缺口/GDP

# 年度增长率（同城市上一年）
df["income_growth"] = df.groupby("城市")["income"].pct_change()
df["expend_growth"] = df.groupby("城市")["expend"].pct_change()
df["gdp_growth"]    = df.groupby("城市")["gdp"].pct_change()

df.to_csv("data_clean/panel_data.csv", index=False, encoding="utf-8-sig")
print("data_clean/panel_data.csv 已生成，shape:", df.shape)
print(df[df["城市"]=="北京"][["城市","year","income","expend","gdp","gap","gap_to_gdp"]].head(10).to_string(index=False))
