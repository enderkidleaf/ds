"""
从国家统计局真实下载数据 - 尝试获取财政指标
"""
import requests, json, time, os
import pandas as pd

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "X-Requested-With": "XMLHttpRequest",
    "Referer": "https://data.stats.gov.cn/easyquery.htm?cn=E0105"
})

# 先访问主页
r = session.get("https://data.stats.gov.cn/easyquery.htm?cn=E0105", timeout=30)
print(f"主页状态: {r.status_code}")

url = "https://data.stats.gov.cn/easyquery.htm"

# 获取所有指标
print("\n获取指标列表...")
params = {
    "m": "getOtherWds",
    "id": "zb",
    "dbcode": "csnd",
    "rowcode": "reg",
    "colcode": "sj",
    "wds": "[]",
    "k1": str(int(time.time()*1000))
}
r = session.get(url, params=params, timeout=30)
data = r.json()

print("可用指标:")
for item in data.get("returndata", []):
    if item.get("wdcode") == "zb":
        for node in item.get("nodes", []):
            print(f"  {node['code']}: {node['name']}")

# 查找财政相关指标
print("\n查找财政相关指标...")
for item in data.get("returndata", []):
    if item.get("wdcode") == "zb":
        for node in item.get("nodes", []):
            name = node['name']
            if '财政' in name or '收入' in name or '支出' in name or '预算' in name:
                print(f"  找到: {node['code']} - {name}")

# 获取地区列表
print("\n获取地区列表...")
params2 = {
    "m": "getOtherWds",
    "id": "reg",
    "dbcode": "csnd",
    "rowcode": "reg",
    "colcode": "sj",
    "wds": "[]",
    "k1": str(int(time.time()*1000))
}
r2 = session.get(url, params=params2, timeout=30)
data2 = r2.json()
print(f"地区数据返回码: {data2.get('returncode')}")
if data2.get('returncode') == 200:
    for item in data2.get("returndata", []):
        if item.get("wdcode") == "reg":
            cities = item.get("nodes", [])
            print(f"找到 {len(cities)} 个地区")
            for c in cities[:10]:
                print(f"  {c['code']}: {c['name']}")
