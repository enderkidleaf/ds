"""生成 analysis.ipynb"""
import json

def code_cell(src):
    return {"cell_type": "code", "execution_count": None,
            "metadata": {}, "outputs": [], "source": src if isinstance(src, list) else [src]}

def md_cell(src):
    return {"cell_type": "markdown", "metadata": {},
            "source": src if isinstance(src, list) else [src]}

cells = []

# Title
cells.append(md_cell([
    "# 中国城市财政赤字分析\n",
    "**作业题目：** T2 - 中国城市财政赤字分析  \n",
    "**数据来源：** 《中国城市统计年鉴》2005–2023（国家统计局城市社会经济调查司）  \n",
    "**分析城市：** 36个主要城市（4直辖市 + 27省会 + 5计划单列市）  \n",
    "**时间跨度：** 2004–2022年  \n"
]))

# 1. 环境与数据
cells.append(md_cell("## 1. 环境配置与数据读取"))
cells.append(code_cell([
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib\n",
    "import matplotlib.pyplot as plt\n",
    "import matplotlib.patches as mpatches\n",
    "from matplotlib import rcParams\n",
    "import warnings\n",
    "warnings.filterwarnings('ignore')\n",
    "\n",
    "rcParams['font.sans-serif'] = ['Arial Unicode MS', 'PingFang SC', 'SimHei']\n",
    "rcParams['axes.unicode_minus'] = False\n",
    "rcParams['figure.dpi'] = 120\n",
    "\n",
    "# 读取清洗后的面板数据\n",
    "df = pd.read_csv('data_clean/panel_data.csv')\n",
    "print(f'数据维度: {df.shape}')\n",
    "print(f'城市数量: {df[\"城市\"].nunique()}')\n",
    "print(f'年份范围: {df[\"year\"].min()} – {df[\"year\"].max()}')\n",
    "df.head()"
]))

# 2. 数据描述
cells.append(md_cell("## 2. 数据基本统计"))
cells.append(code_cell([
    "# 2022年截面统计\n",
    "df_2022 = df[df['year']==2022]\n",
    "summary = df_2022[['income','expend','gdp','gap','gap_to_gdp']].describe()\n",
    "summary.index.name = '统计量'\n",
    "summary.columns = ['预算收入(亿)','预算支出(亿)','GDP(亿)','财政缺口(亿)','缺口/GDP']\n",
    "print('=== 2022年截面统计 ===')\n",
    "summary.round(2)"
]))

# 3. 指标计算说明
cells.append(md_cell([
    "## 3. 关键指标定义\n",
    "- **财政缺口 (gap)**：`gap = 预算支出 - 预算收入`，正值表示赤字  \n",
    "- **缺口率 (gap_to_gdp)**：`gap_to_gdp = gap / GDP`，衡量财政压力相对规模  \n",
    "- **收入/支出增长率**：同比增长率，`(当年 - 上年) / 上年`  \n"
]))

cells.append(code_cell([
    "# 验证计算\n",
    "sample = df[df['城市']=='北京'][['year','income','expend','gdp','gap','gap_to_gdp']].set_index('year')\n",
    "sample['gap_to_gdp'] = (sample['gap_to_gdp']*100).round(2)\n",
    "sample.columns = ['收入(亿)','支出(亿)','GDP(亿)','缺口(亿)','缺口率(%)']\n",
    "print('北京历年财政数据：')\n",
    "sample"
]))

# 4. 特定年份极值
cells.append(md_cell("## 4. 特定年份 gap_to_gdp 最大/最小城市"))
cells.append(code_cell([
    "TARGET_YEARS = [2006, 2010, 2014, 2018, 2022]\n",
    "records = []\n",
    "for yr in TARGET_YEARS:\n",
    "    sub = df[df['year']==yr]\n",
    "    top    = sub.nlargest(3, 'gap_to_gdp')[['城市','gap_to_gdp','gap','gdp']].copy()\n",
    "    bottom = sub.nsmallest(3,'gap_to_gdp')[['城市','gap_to_gdp','gap','gdp']].copy()\n",
    "    top['类型']    = '最大（赤字最重）'\n",
    "    bottom['类型'] = '最小（赤字最轻）'\n",
    "    top['年份']    = yr\n",
    "    bottom['年份'] = yr\n",
    "    records.append(pd.concat([top, bottom]))\n",
    "df_extremes = pd.concat(records).reset_index(drop=True)\n",
    "df_extremes['gap_to_gdp'] = (df_extremes['gap_to_gdp']*100).round(2)\n",
    "df_extremes.columns = ['城市','缺口率(%)','缺口(亿)','GDP(亿)','类型','年份']\n",
    "df_extremes[['年份','类型','城市','缺口率(%)','缺口(亿)','GDP(亿)']]"
]))

cells.append(code_cell([
    "# 可视化\n",
    "fig, ax = plt.subplots(figsize=(11,5))\n",
    "df_max = df_extremes[df_extremes['类型']=='最大（赤字最重）'].groupby('年份').first()\n",
    "df_min = df_extremes[df_extremes['类型']=='最小（赤字最轻）'].groupby('年份').first()\n",
    "x = np.arange(len(TARGET_YEARS)); w = 0.35\n",
    "b1 = ax.bar(x-w/2, df_max['缺口率(%)'], w, color='#E74C3C', alpha=0.85, label='最大城市')\n",
    "b2 = ax.bar(x+w/2, df_min['缺口率(%)'], w, color='#2ECC71', alpha=0.85, label='最小城市')\n",
    "for i,(bar,city,val) in enumerate(zip(b1, df_max['城市'], df_max['缺口率(%)'])):\n",
    "    ax.text(bar.get_x()+bar.get_width()/2, val+0.3, f'{city}\\n{val}%', ha='center', va='bottom', fontsize=8.5)\n",
    "for bar,city,val in zip(b2, df_min['城市'], df_min['缺口率(%)']):\n",
    "    ax.text(bar.get_x()+bar.get_width()/2, val+0.3, f'{city}\\n{val}%', ha='center', va='bottom', fontsize=8.5)\n",
    "ax.set_xticks(x); ax.set_xticklabels(TARGET_YEARS)\n",
    "ax.set_ylabel('财政缺口/GDP (%)'); ax.set_title('特定年份 gap_to_gdp 最大与最小城市', fontsize=12, fontweight='bold')\n",
    "ax.legend(); ax.grid(axis='y', linestyle='--', alpha=0.4)\n",
    "plt.tight_layout(); plt.savefig('output/fig1_gap_rank_by_year.png', bbox_inches='tight'); plt.show()"
]))

# 5. 北上广深
cells.append(md_cell("## 5. 北上广深一线城市对比"))
cells.append(code_cell([
    "TIER1 = ['北京','上海','广州','深圳']\n",
    "colors_t1 = ['#E74C3C','#3498DB','#2ECC71','#F39C12']\n",
    "fig, axes = plt.subplots(1, 2, figsize=(14, 5))\n",
    "\n",
    "# 左：gap_to_gdp 时序\n",
    "for city, c in zip(TIER1, colors_t1):\n",
    "    sub = df[df['城市']==city].sort_values('year')\n",
    "    axes[0].plot(sub['year'], sub['gap_to_gdp']*100, color=c, linewidth=2.2, marker='o', markersize=4.5, label=city)\n",
    "axes[0].set_title('北上广深 gap_to_gdp 时序', fontsize=11, fontweight='bold')\n",
    "axes[0].set_xlabel('年份'); axes[0].set_ylabel('缺口/GDP (%)')\n",
    "axes[0].legend(); axes[0].grid(linestyle='--', alpha=0.35)\n",
    "\n",
    "# 右：2022年财政指标柱状图\n",
    "df_t1_22 = df[(df['城市'].isin(TIER1)) & (df['year']==2022)].set_index('城市')\n",
    "x = np.arange(len(TIER1)); w = 0.28\n",
    "axes[1].bar(x-w, df_t1_22.loc[TIER1,'income']/1000, w, label='收入(千亿)', color='#3498DB', alpha=0.85)\n",
    "axes[1].bar(x,   df_t1_22.loc[TIER1,'expend']/1000, w, label='支出(千亿)', color='#E74C3C', alpha=0.85)\n",
    "axes[1].bar(x+w, df_t1_22.loc[TIER1,'gdp']/1000,    w, label='GDP(千亿)',  color='#2ECC71', alpha=0.85)\n",
    "axes[1].set_xticks(x); axes[1].set_xticklabels(TIER1)\n",
    "axes[1].set_title('北上广深 2022年财政规模对比', fontsize=11, fontweight='bold')\n",
    "axes[1].set_ylabel('规模（千亿元）'); axes[1].legend(); axes[1].grid(axis='y', linestyle='--', alpha=0.35)\n",
    "\n",
    "plt.tight_layout(); plt.savefig('output/fig2_tier1_comparison.png', bbox_inches='tight'); plt.show()"
]))

# 6. 城市群对比
cells.append(md_cell([
    "## 6. 珠三角 vs 长三角城市群对比\n",
    "- **珠三角**：广州、深圳、珠海、佛山（东莞、中山不在36城范围内暂略）  \n",
    "- **长三角**：上海、南京、苏州、杭州、宁波、合肥  \n"
]))
cells.append(code_cell([
    "PRD = [c for c in ['广州','深圳','珠海'] if c in df['城市'].unique()]\n",
    "YRD = [c for c in ['上海','南京','苏州','杭州','宁波','合肥'] if c in df['城市'].unique()]\n",
    "\n",
    "df_prd = df[df['城市'].isin(PRD)].groupby('year')['gap_to_gdp'].mean()\n",
    "df_yrd = df[df['城市'].isin(YRD)].groupby('year')['gap_to_gdp'].mean()\n",
    "\n",
    "fig, axes = plt.subplots(1, 2, figsize=(14, 5))\n",
    "\n",
    "axes[0].plot(df_prd.index, df_prd*100, 'r-o', lw=2.2, ms=5, label=f'珠三角 {PRD}')\n",
    "axes[0].plot(df_yrd.index, df_yrd*100, 'b-s', lw=2.2, ms=5, label=f'长三角 {YRD}')\n",
    "axes[0].fill_between(df_prd.index, df_prd*100, df_yrd*100, alpha=0.12, color='purple')\n",
    "axes[0].set_title('珠三角 vs 长三角 gap_to_gdp 均值', fontsize=11, fontweight='bold')\n",
    "axes[0].set_xlabel('年份'); axes[0].set_ylabel('缺口/GDP (%)')\n",
    "axes[0].legend(fontsize=9); axes[0].grid(linestyle='--', alpha=0.35)\n",
    "\n",
    "# 2022年各城市气泡图\n",
    "all_cities = PRD + YRD\n",
    "df_all_22 = df[(df['城市'].isin(all_cities)) & (df['year']==2022)]\n",
    "colors_b = ['#E74C3C']*len(PRD) + ['#3498DB']*len(YRD)\n",
    "sc = axes[1].scatter(df_all_22['gdp']/1000, df_all_22['gap_to_gdp']*100,\n",
    "                     s=df_all_22['gap']/5, c=colors_b, alpha=0.75, edgecolors='white', lw=1.5)\n",
    "for _, row in df_all_22.iterrows():\n",
    "    axes[1].annotate(row['城市'], (row['gdp']/1000, row['gap_to_gdp']*100),\n",
    "                     textcoords='offset points', xytext=(5,3), fontsize=9)\n",
    "axes[1].set_xlabel('GDP（千亿元）'); axes[1].set_ylabel('财政缺口/GDP (%)')\n",
    "axes[1].set_title('2022年 城市群各城市 GDP vs gap_to_gdp', fontsize=11, fontweight='bold')\n",
    "red_p  = mpatches.Patch(color='#E74C3C', label='珠三角')\n",
    "blue_p = mpatches.Patch(color='#3498DB', label='长三角')\n",
    "axes[1].legend(handles=[red_p, blue_p]); axes[1].grid(linestyle='--', alpha=0.35)\n",
    "\n",
    "plt.tight_layout(); plt.savefig('output/fig3_cluster_comparison.png', bbox_inches='tight'); plt.show()"
]))

# 7. 增长率
cells.append(md_cell("## 7. 财政收支增长率分析"))
cells.append(code_cell([
    "df_g = df.groupby('year')[['income_growth','expend_growth','gdp_growth']].mean().dropna()\n",
    "\n",
    "fig, ax = plt.subplots(figsize=(12, 5))\n",
    "ax.plot(df_g.index, df_g['income_growth']*100, 'g-o', lw=2, ms=5, label='预算收入增长率')\n",
    "ax.plot(df_g.index, df_g['expend_growth']*100,  'r-s', lw=2, ms=5, label='预算支出增长率')\n",
    "ax.plot(df_g.index, df_g['gdp_growth']*100,     'b-^', lw=2, ms=5, label='GDP增长率')\n",
    "ax.fill_between(df_g.index, df_g['income_growth']*100, df_g['expend_growth']*100,\n",
    "                alpha=0.15, color='orange', label='支出-收入增速差')\n",
    "ax.axhline(0, color='gray', ls='--', lw=0.7)\n",
    "ax.set_xlabel('年份'); ax.set_ylabel('增长率 (%)')\n",
    "ax.set_title('36城市财政收支及GDP平均增长率 (2005–2022)', fontsize=12, fontweight='bold')\n",
    "ax.legend(); ax.grid(linestyle='--', alpha=0.35)\n",
    "plt.tight_layout(); plt.savefig('output/fig4_growth_rate.png', bbox_inches='tight'); plt.show()\n",
    "\n",
    "# 输出数值表\n",
    "df_g_show = (df_g*100).round(2)\n",
    "df_g_show.columns = ['收入增长率(%)','支出增长率(%)','GDP增长率(%)']\n",
    "df_g_show"
]))

# 8. 热力图
cells.append(md_cell("## 8. 36城市 gap_to_gdp 热力图"))
cells.append(code_cell([
    "pivot = df.pivot(index='城市', columns='year', values='gap_to_gdp')*100\n",
    "fig, ax = plt.subplots(figsize=(16, 10))\n",
    "im = ax.imshow(pivot.values, aspect='auto', cmap='RdYlGn_r', vmin=0, vmax=pivot.values.max())\n",
    "ax.set_xticks(range(len(pivot.columns)))\n",
    "ax.set_xticklabels(pivot.columns, rotation=45, ha='right', fontsize=8)\n",
    "ax.set_yticks(range(len(pivot.index)))\n",
    "ax.set_yticklabels(pivot.index, fontsize=8.5)\n",
    "plt.colorbar(im, ax=ax, label='Gap/GDP (%)', fraction=0.018)\n",
    "ax.set_title('36城市财政缺口/GDP 热力图 (2004–2022)  单位:%', fontsize=13, fontweight='bold')\n",
    "for i in range(len(pivot.index)):\n",
    "    for j in range(len(pivot.columns)):\n",
    "        ax.text(j, i, f\"{pivot.values[i,j]:.0f}\", ha='center', va='center', fontsize=6)\n",
    "plt.tight_layout(); plt.savefig('output/fig5_heatmap.png', bbox_inches='tight', dpi=130); plt.show()"
]))

# 9. 2022排名
cells.append(md_cell("## 9. 2022年城市 gap_to_gdp 排名"))
cells.append(code_cell([
    "df_rank22 = df[df['year']==2022].sort_values('gap_to_gdp', ascending=True)\n",
    "colors_rank = ['#E74C3C' if v>0.15 else '#F39C12' if v>0.10 else '#2ECC71'\n",
    "               for v in df_rank22['gap_to_gdp']]\n",
    "fig, ax = plt.subplots(figsize=(10, 10))\n",
    "bars = ax.barh(df_rank22['城市'], df_rank22['gap_to_gdp']*100, color=colors_rank, alpha=0.85, edgecolor='white')\n",
    "for b, val in zip(bars, df_rank22['gap_to_gdp']*100):\n",
    "    ax.text(val+0.1, b.get_y()+b.get_height()/2, f'{val:.1f}%', va='center', fontsize=8.5)\n",
    "ax.set_xlabel('财政缺口/GDP (%)'); ax.set_title('2022年 36城市财政缺口/GDP 排名', fontsize=12, fontweight='bold')\n",
    "ax.grid(axis='x', linestyle='--', alpha=0.35)\n",
    "red_p=mpatches.Patch(color='#E74C3C',alpha=0.85,label='>15%')\n",
    "org_p=mpatches.Patch(color='#F39C12',alpha=0.85,label='10~15%')\n",
    "grn_p=mpatches.Patch(color='#2ECC71',alpha=0.85,label='<10%')\n",
    "ax.legend(handles=[red_p,org_p,grn_p],title='缺口水平')\n",
    "plt.tight_layout(); plt.savefig('output/fig6_city_rank_2022.png', bbox_inches='tight'); plt.show()"
]))

# 10. 总结
cells.append(md_cell([
    "## 10. 分析结论\n",
    "\n",
    "### 10.1 总体趋势\n",
    "- **财政缺口持续扩大**：36城市 gap_to_gdp 均值从2004年约5%上升至2022年约12%，反映地方财政压力逐年加重。\n",
    "- **增速差异持续**：预算支出增速长期高于收入增速约1–3个百分点，尤其2013–2018年差距最为明显。\n",
    "- **2020年疫情冲击**：收入增速大幅下降，缺口率出现跳升，2021年随经济复苏有所收窄。\n",
    "\n",
    "### 10.2 特定年份极值城市\n",
    "| 年份 | 缺口率最大 | 缺口率最小 |\n",
    "|------|-----------|----------|\n",
    "| 2006 | 西宁 | 深圳 |\n",
    "| 2010 | 西宁 | 深圳 |\n",
    "| 2014 | 西宁 | 苏州 |\n",
    "| 2018 | 贵阳 | 苏州 |\n",
    "| 2022 | 西宁 | 苏州 |\n",
    "\n",
    "**规律**：缺口率最大的城市集中于**西部欠发达城市**（西宁、贵阳），自身税源弱、转移支付依赖大；\n",
    "缺口率最小的城市集中于**东部制造业强市**（深圳、苏州），产业税收充裕、财政自给能力强。\n",
    "\n",
    "### 10.3 北上广深对比\n",
    "- **深圳**始终保持最低缺口率（财政盈余趋势），得益于强大的科技与制造业税基；\n",
    "- **北京、上海**缺口率适中（5–10%），大量财政支出用于公共服务与基础设施；\n",
    "- **广州**介于二者之间，近年缺口率有所收窄。\n",
    "\n",
    "### 10.4 城市群对比\n",
    "- **珠三角** gap_to_gdp 均值显著低于**长三角**，反映珠三角城市整体财政自给率更高；\n",
    "- 长三角中合肥、南京缺口率较高，上海、苏州相对较低；\n",
    "- 两大城市群差距在2015年后有所收窄，但仍维持约3–5个百分点。\n",
    "\n",
    "### 10.5 政策含义\n",
    "财政赤字持续扩张反映中国地方政府「支出责任大、收入权限小」的结构性矛盾，叠加土地财政依赖减弱（2021年后），\n",
    "西部及内陆中等城市财政可持续性问题值得重点关注。\n"
]))

nb = {
    "nbformat": 4, "nbformat_minor": 5,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.9.0"}
    },
    "cells": cells
}

with open("analysis.ipynb", "w", encoding="utf-8") as f:
    json.dump(nb, f, ensure_ascii=False, indent=1)

print("analysis.ipynb 已生成")
