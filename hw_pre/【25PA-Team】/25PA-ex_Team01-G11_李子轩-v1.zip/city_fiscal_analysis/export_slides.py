"""
将 Marp 幻灯片导出为 HTML 和 PDF
"""
import markdown
import os

def marp_to_html(input_file, output_file):
    """将 Marp markdown 转换为 HTML"""
    
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 移除 Marp 配置头
    lines = content.split('\n')
    cleaned_lines = []
    in_header = False
    
    for line in lines:
        if line.strip() == '---':
            if not in_header:
                in_header = True
                continue
            else:
                in_header = False
                continue
        if in_header and (line.startswith('marp:') or line.startswith('theme:') or 
                          line.startswith('paginate:') or line.startswith('backgroundColor:') or
                          line.startswith('style:')):
            continue
        cleaned_lines.append(line)
    
    cleaned_content = '\n'.join(cleaned_lines)
    
    # 分割幻灯片
    slides = cleaned_content.split('\n---\n')
    
    # 构建 HTML
    html_parts = [
        '<!DOCTYPE html>',
        '<html lang="zh-CN">',
        '<head>',
        '    <meta charset="UTF-8">',
        '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
        '    <title>中国主要城市财政赤字分析</title>',
        '    <style>',
        '        * { margin: 0; padding: 0; box-sizing: border-box; }',
        '        body { font-family: "Arial", "Microsoft YaHei", sans-serif; background: #f0f0f0; }',
        '        .slide {',
        '            width: 960px;',
        '            height: 540px;',
        '            margin: 40px auto;',
        '            padding: 60px;',
        '            background: white;',
        '            box-shadow: 0 4px 20px rgba(0,0,0,0.15);',
        '            page-break-after: always;',
        '            display: flex;',
        '            flex-direction: column;',
        '            justify-content: center;',
        '        }',
        '        .slide:last-child { page-break-after: auto; }',
        '        h1 { color: #2F5496; font-size: 36px; margin-bottom: 30px; }',
        '        h2 { color: #C00000; font-size: 28px; margin: 20px 0; }',
        '        h3 { color: #333; font-size: 24px; margin: 15px 0; }',
        '        p { font-size: 20px; line-height: 1.6; margin: 10px 0; }',
        '        ul, ol { font-size: 20px; line-height: 1.8; margin: 15px 0 15px 30px; }',
        '        li { margin: 8px 0; }',
        '        table {',
        '            width: 100%;',
        '            border-collapse: collapse;',
        '            margin: 20px 0;',
        '            font-size: 18px;',
        '        }',
        '        th, td {',
        '            border: 1px solid #ddd;',
        '            padding: 12px;',
        '            text-align: center;',
        '        }',
        '        th { background: #2F5496; color: white; }',
        '        tr:nth-child(even) { background: #f9f9f9; }',
        '        .center { text-align: center; }',
        '        .highlight { color: #C00000; font-weight: bold; }',
        '        .footer {',
        '            position: absolute;',
        '            bottom: 20px;',
        '            right: 40px;',
        '            font-size: 14px;',
        '            color: #666;',
        '        }',
        '        @media print {',
        '            .slide { margin: 0; box-shadow: none; }',
        '            body { background: white; }',
        '        }',
        '    </style>',
        '</head>',
        '<body>',
    ]
    
    for i, slide_content in enumerate(slides):
        slide_html = markdown.markdown(slide_content, extensions=['tables'])
        slide_html = slide_html.replace('<h1>', '<h1>').replace('<h2>', '<h2>')
        html_parts.append(f'    <div class="slide">{slide_html}</div>')
    
    html_parts.extend([
        '</body>',
        '</html>',
    ])
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(html_parts))
    
    print(f"HTML 已生成: {output_file}")


if __name__ == "__main__":
    marp_to_html("Report_slides.md", "Report_slides.html")
    print("\n提示：")
    print("1. HTML版本可直接在浏览器中打开查看")
    print("2. 在浏览器中按 Ctrl+P 可导出为PDF")
    print("3. 或使用在线Marp工具：https://web.marp.app/")
