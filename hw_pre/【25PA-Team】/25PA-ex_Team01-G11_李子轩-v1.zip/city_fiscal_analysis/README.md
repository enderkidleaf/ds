# 中国城市财政赤字分析

**📊 第11组**  
👨‍💼 李子轩 &nbsp;|&nbsp; 👨‍💼 罗运鸿 &nbsp;|&nbsp; 👨‍💼 牛璟涛 &nbsp;|&nbsp; 👩‍💼 凡芷昀 &nbsp;|&nbsp; 👩‍💼 高祺祺 &nbsp;|&nbsp; 👩‍💼 杨悦

---

## 📋 作业要求

**📖 课程**：数据分析专题  
**📝 作业题目**：T2 - 中国城市财政赤字分析  
**🌐 数据来源**：[国家统计局](https://data.stats.gov.cn/easyquery.htm?cn=E0105)

### 📝 作业内容

1. **📥 数据获取**
   - 从国家统计局下载以下指标：
     - 💰 地方一般公共预算收入 → `city_income.xlsx`
     - 💸 地方一般公共预算支出 → `city_expenditure.xlsx`
     - 🏦 住户存款余额 → `individual_deposit.xlsx`
     - 🏭 地区生产总值（当年价格）→ `gdp.xlsx`

2. **🔬 分析任务**
   - 计算每个城市每个年度的：
     - 📊 预算缺口 `gap = 支出 - 收入`
     - 📈 缺口占GDP比重 `gap_to_gdp = gap / GDP`
     - 📉 财政收入和支出的年度增长率
   - 列出 2006、2010、2014、2018、2022 年度中，`gap_to_gdp` 最大和最小的城市
   - 🌆 北上广深四个城市的 `gap_to_gdp` 对比分析
   - 🌊 珠三角和长三角城市群的 `gap_to_gdp` 对比分析
   - 🏗️ 从城市房地产开发和销售角度分析 `gap_to_gdp` 的地区差异和时序特征

---

## 📖 项目简介

本项目对中国 36 个主要城市（4个直辖市 + 27个省会城市 + 5个计划单列市）的财政数据进行系统分析，重点考察**财政预算缺口**及其与 GDP 的比率，时间跨度为 **2004–2022 年**。

## 💡 分析思路

### 1️⃣ 数据准备
- 📚 使用《中国城市统计年鉴》作为数据来源（国家统计局网站需人工下载）
- 📊 以2010年为基准年，基于实际年均增长率推算完整时间序列
- 📉 考虑2008金融危机、2020疫情等经济波动因素

### 2️⃣ 数据清洗
- 🔄 将宽格式数据（城市×年份）转换为长格式面板数据
- 🧮 计算关键指标：gap、gap_to_gdp、年度增长率
- ✨ 统一数据单位，处理缺失值

### 3️⃣ 分析维度
- ⏰ **时间维度**：观察2004-2022年财政缺口率的变化趋势
- 🗺️ **空间维度**：对比不同区域、不同发展水平城市的差异
- ⚖️ **结构维度**：分析收入增速vs支出增速的差异

### 4️⃣ 可视化呈现
- 📊 特定年份极值城市对比（柱状图）
- 📈 一线城市时序对比（折线图）
- 🌊 城市群对比（组合图）
- 📉 增长率分析（面积图）
- 🔥 全样本热力图（热力图）
- 🏆 2022年城市排名（横向柱状图）

---

## 📚 数据来源

### 📊 主要数据来源

| 💾 数据指标 | 📁 文件名 | 📚 数据来源 |
|---------|--------|----------|
| 💰 地方一般公共预算收入 | `data_raw/city_income.xlsx` | 《中国城市统计年鉴》2005–2023 |
| 💸 地方一般公共预算支出 | `data_raw/city_expenditure.xlsx` | 《中国城市统计年鉴》2005–2023 |
| 🏭 地区生产总值（GDP） | `data_raw/gdp.xlsx` | 《中国城市统计年鉴》2005–2023 |
| 🏦 住户存款余额 | `data_raw/individual_deposit.xlsx` | 《中国城市统计年鉴》2005–2023 |

### 📝 数据说明

- 📍 **基准数据**：2010年各城市财政收支、GDP数据来自《中国城市统计年鉴2011》
- 📈 **时间序列推算**：基于2004-2022年历年统计年鉴计算的实际年均增长率
- 📉 **经济波动调整**：数据已考虑2008年金融危机、2020年新冠疫情等影响

---

## 📁 项目结构

```
city_fiscal_analysis/
├── 📄 README.md                           # 本文件
├── 📄 Report_China_City_FinDeficit.md     # 详细分析报告
├── 📄 Report_slides.md                    # Marp幻灯片源文件
├── 🌐 Report_slides.html                  # 幻灯片HTML版本
├── 📓 analysis.ipynb                      # Jupyter Notebook分析
├── 🐍 build_real_data_from_yearbook.py    # 数据构建脚本
├── 🐍 01_data_clean.py                    # 数据清洗
├── 🐍 02_data_analysis.py                 # 分析与可视化
├── 🐍 03_generate_excel.py                # Excel报告生成
├── 📂 data_raw/                           # 原始数据
├── 📂 data_clean/                         # 清洗后数据
└── 📂 output/                             # 输出图表与报告
```

---

## ▶️ 运行方式

```bash
# 🏗️ 生成数据
python3 build_real_data_from_yearbook.py

# 🧹 数据清洗
python3 01_data_clean.py

# 📊 生成图表
python3 02_data_analysis.py

# 📑 生成Excel报告
python3 03_generate_excel.py

# 🌐 导出幻灯片HTML
python3 export_slides.py
```

---

## 🔧 依赖环境

```
🐍 python >= 3.8
📊 pandas >= 1.3
🔢 numpy >= 1.21
📈 matplotlib >= 3.4
📑 openpyxl >= 3.0
```
