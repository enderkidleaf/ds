"""
数据分析与可视化脚本
任务：
  1. 特定年份 gap_to_gdp 最大/最小城市
  2. 北上广深对比
  3. 珠三角 vs 长三角对比
  4. 增长率分析
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib import rcParams
import os, warnings
warnings.filterwarnings("ignore")

# 中文字体
rcParams["font.sans-serif"] = ["Arial Unicode MS", "PingFang SC", "Heiti SC", "SimHei"]
rcParams["axes.unicode_minus"] = False
rcParams["figure.dpi"] = 150

os.makedirs("output", exist_ok=True)

df = pd.read_csv("data_clean/panel_data.csv")

# ═══════════════════════════════════════════
# 1. 特定年份 gap_to_gdp 最大/最小城市
# ═══════════════════════════════════════════
TARGET_YEARS = [2006, 2010, 2014, 2018, 2022]
records = []
for yr in TARGET_YEARS:
    sub = df[df["year"] == yr].copy()
    top1    = sub.nlargest(1, "gap_to_gdp").iloc[0]
    bottom1 = sub.nsmallest(1, "gap_to_gdp").iloc[0]
    records.append({
        "年份": yr,
        "缺口/GDP最大城市": top1["城市"],
        "最大值": round(top1["gap_to_gdp"] * 100, 2),
        "缺口/GDP最小城市": bottom1["城市"],
        "最小值": round(bottom1["gap_to_gdp"] * 100, 2)
    })
df_rank = pd.DataFrame(records)
df_rank.to_csv("data_clean/gap_rank_by_year.csv", index=False, encoding="utf-8-sig")
print("=== 特定年份 gap_to_gdp 最大/最小城市 ===")
print(df_rank.to_string(index=False))

# 可视化：分组柱状图
fig, ax = plt.subplots(figsize=(11, 5))
x = np.arange(len(TARGET_YEARS))
w = 0.35
bars1 = ax.bar(x - w/2, df_rank["最大值"], w, color="#E74C3C", alpha=0.85, label="最大城市")
bars2 = ax.bar(x + w/2, df_rank["最小值"], w, color="#2ECC71", alpha=0.85, label="最小城市")

for i, (b1, b2, row) in enumerate(zip(bars1, bars2, records)):
    ax.text(b1.get_x() + b1.get_width()/2, b1.get_height() + 0.2,
            f"{row['缺口/GDP最大城市']}\n{row['最大值']}%", ha="center", va="bottom", fontsize=8.5)
    ax.text(b2.get_x() + b2.get_width()/2, b2.get_height() + 0.2,
            f"{row['缺口/GDP最小城市']}\n{row['最小值']}%", ha="center", va="bottom", fontsize=8.5)

ax.set_xticks(x)
ax.set_xticklabels(TARGET_YEARS, fontsize=11)
ax.set_ylabel("财政缺口/GDP (%)", fontsize=11)
ax.set_title("特定年份 Gap-to-GDP 最大与最小城市比较", fontsize=13, fontweight="bold")
ax.legend(fontsize=10)
ax.set_ylim(0, df_rank["最大值"].max() * 1.35)
ax.grid(axis="y", linestyle="--", alpha=0.4)
plt.tight_layout()
plt.savefig("output/fig1_gap_rank_by_year.png", bbox_inches="tight")
plt.close()
print("-> 图1已保存")

# ═══════════════════════════════════════════
# 2. 北上广深 gap_to_gdp 时序对比
# ═══════════════════════════════════════════
TIER1 = ["北京", "上海", "广州", "深圳"]
colors_t1 = ["#E74C3C", "#3498DB", "#2ECC71", "#F39C12"]
markers_t1 = ["o", "s", "^", "D"]

fig, ax = plt.subplots(figsize=(12, 5.5))
for city, c, m in zip(TIER1, colors_t1, markers_t1):
    sub = df[df["城市"] == city].sort_values("year")
    ax.plot(sub["year"], sub["gap_to_gdp"] * 100, color=c, marker=m,
            linewidth=2.2, markersize=5.5, label=city)

ax.axhline(0, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)
ax.set_xlabel("年份", fontsize=11)
ax.set_ylabel("财政缺口/GDP (%)", fontsize=11)
ax.set_title("北上广深一线城市财政缺口/GDP 时序对比 (2004–2022)", fontsize=13, fontweight="bold")
ax.legend(fontsize=11)
ax.grid(linestyle="--", alpha=0.35)
ax.set_xticks(range(2004, 2023, 2))
plt.tight_layout()
plt.savefig("output/fig2_tier1_gap_to_gdp.png", bbox_inches="tight")
plt.close()
print("-> 图2已保存")

# ═══════════════════════════════════════════
# 3. 珠三角 vs 长三角 gap_to_gdp 均值对比
# ═══════════════════════════════════════════
PRD = ["广州", "深圳", "东莞", "佛山", "珠海", "中山"]   # 珠三角
YRD = ["上海", "南京", "苏州", "杭州", "宁波", "合肥"]   # 长三角

# 取数据中存在的城市
PRD = [c for c in PRD if c in df["城市"].unique()]
YRD = [c for c in YRD if c in df["城市"].unique()]

df_prd = df[df["城市"].isin(PRD)].groupby("year")["gap_to_gdp"].mean().reset_index()
df_yrd = df[df["城市"].isin(YRD)].groupby("year")["gap_to_gdp"].mean().reset_index()

fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), sharey=False)

# 左图：时序折线
ax = axes[0]
ax.plot(df_prd["year"], df_prd["gap_to_gdp"] * 100, "r-o", linewidth=2.2, markersize=5, label=f"珠三角 ({', '.join(PRD)})")
ax.plot(df_yrd["year"], df_yrd["gap_to_gdp"] * 100, "b-s", linewidth=2.2, markersize=5, label=f"长三角 ({', '.join(YRD)})")
ax.set_xlabel("年份", fontsize=11)
ax.set_ylabel("财政缺口/GDP (%)", fontsize=11)
ax.set_title("珠三角 vs 长三角 gap_to_gdp 均值对比", fontsize=12, fontweight="bold")
ax.legend(fontsize=9)
ax.grid(linestyle="--", alpha=0.35)
ax.set_xticks(range(2004, 2023, 3))

# 右图：各城市 2022 年横向对比
ax2 = axes[1]
df_2022 = df[df["year"] == 2022].copy()
cities_compare = PRD + YRD
df_comp = df_2022[df_2022["城市"].isin(cities_compare)].set_index("城市")["gap_to_gdp"] * 100
df_comp = df_comp.reindex(cities_compare).dropna()
colors_bar = ["#E74C3C"] * len(PRD) + ["#3498DB"] * len(YRD)
bar_colors = [colors_bar[cities_compare.index(c)] for c in df_comp.index]
bars = ax2.bar(df_comp.index, df_comp.values, color=bar_colors, alpha=0.85, edgecolor="white")
for b in bars:
    ax2.text(b.get_x() + b.get_width()/2, b.get_height() + 0.1,
             f"{b.get_height():.1f}%", ha="center", va="bottom", fontsize=8.5)
ax2.set_ylabel("财政缺口/GDP (%)", fontsize=11)
ax2.set_title("2022年 珠三角 vs 长三角 各城市对比", fontsize=12, fontweight="bold")
ax2.grid(axis="y", linestyle="--", alpha=0.35)
red_p = mpatches.Patch(color="#E74C3C", alpha=0.85, label="珠三角")
blue_p = mpatches.Patch(color="#3498DB", alpha=0.85, label="长三角")
ax2.legend(handles=[red_p, blue_p], fontsize=10)
plt.tight_layout()
plt.savefig("output/fig3_prd_yrd_comparison.png", bbox_inches="tight")
plt.close()
print("-> 图3已保存")

# ═══════════════════════════════════════════
# 4. 增长率分析（收入 & 支出）
# ═══════════════════════════════════════════
# 全国均值增长率
df_growth_avg = df.groupby("year")[["income_growth", "expend_growth", "gdp_growth"]].mean().dropna()
fig, ax = plt.subplots(figsize=(12, 5))
ax.plot(df_growth_avg.index, df_growth_avg["income_growth"] * 100, "g-o", linewidth=2, markersize=5, label="预算收入增长率")
ax.plot(df_growth_avg.index, df_growth_avg["expend_growth"] * 100, "r-s", linewidth=2, markersize=5, label="预算支出增长率")
ax.plot(df_growth_avg.index, df_growth_avg["gdp_growth"] * 100, "b-^", linewidth=2, markersize=5, label="GDP增长率")
ax.axhline(0, color="black", linestyle="--", linewidth=0.7)
ax.fill_between(df_growth_avg.index,
                df_growth_avg["income_growth"] * 100,
                df_growth_avg["expend_growth"] * 100,
                alpha=0.15, color="orange", label="支出-收入增速差")
ax.set_xlabel("年份", fontsize=11)
ax.set_ylabel("增长率 (%)", fontsize=11)
ax.set_title("36城市财政收支及GDP平均增长率 (2005–2022)", fontsize=13, fontweight="bold")
ax.legend(fontsize=10)
ax.grid(linestyle="--", alpha=0.35)
ax.set_xticks(range(2005, 2023, 2))
plt.tight_layout()
plt.savefig("output/fig4_growth_rate.png", bbox_inches="tight")
plt.close()
print("-> 图4已保存")

# ═══════════════════════════════════════════
# 5. 热力图：各城市 gap_to_gdp 演变
# ═══════════════════════════════════════════
pivot = df.pivot(index="城市", columns="year", values="gap_to_gdp") * 100
fig, ax = plt.subplots(figsize=(16, 10))
im = ax.imshow(pivot.values, aspect="auto", cmap="RdYlGn_r", vmin=0, vmax=pivot.values.max())
ax.set_xticks(range(len(pivot.columns)))
ax.set_xticklabels(pivot.columns, rotation=45, ha="right", fontsize=8)
ax.set_yticks(range(len(pivot.index)))
ax.set_yticklabels(pivot.index, fontsize=8.5)
plt.colorbar(im, ax=ax, label="Gap/GDP (%)", fraction=0.025)
ax.set_title("36城市财政缺口/GDP 热力图 (2004–2022)  单位:%", fontsize=13, fontweight="bold")
# 标注数值
for i in range(len(pivot.index)):
    for j in range(len(pivot.columns)):
        val = pivot.values[i, j]
        ax.text(j, i, f"{val:.0f}", ha="center", va="center",
                fontsize=6, color="black" if val < pivot.values.max() * 0.6 else "white")
plt.tight_layout()
plt.savefig("output/fig5_heatmap.png", bbox_inches="tight", dpi=130)
plt.close()
print("-> 图5已保存")

# ═══════════════════════════════════════════
# 6. 2022年横截面：gap_to_gdp 城市排名
# ═══════════════════════════════════════════
df_2022 = df[df["year"] == 2022].sort_values("gap_to_gdp", ascending=True)
colors_rank = ["#E74C3C" if v > 0.15 else "#F39C12" if v > 0.10 else "#2ECC71"
               for v in df_2022["gap_to_gdp"]]
fig, ax = plt.subplots(figsize=(10, 10))
bars = ax.barh(df_2022["城市"], df_2022["gap_to_gdp"] * 100, color=colors_rank, alpha=0.85, edgecolor="white")
for b, val in zip(bars, df_2022["gap_to_gdp"] * 100):
    ax.text(val + 0.1, b.get_y() + b.get_height()/2, f"{val:.1f}%", va="center", fontsize=8.5)
ax.set_xlabel("财政缺口/GDP (%)", fontsize=11)
ax.set_title("2022年 36城市财政缺口/GDP 排名", fontsize=13, fontweight="bold")
ax.grid(axis="x", linestyle="--", alpha=0.35)
red_p   = mpatches.Patch(color="#E74C3C", alpha=0.85, label=">15%")
orange_p= mpatches.Patch(color="#F39C12", alpha=0.85, label="10%~15%")
green_p = mpatches.Patch(color="#2ECC71", alpha=0.85, label="<10%")
ax.legend(handles=[red_p, orange_p, green_p], fontsize=10, title="缺口水平", title_fontsize=10)
plt.tight_layout()
plt.savefig("output/fig6_city_rank_2022.png", bbox_inches="tight")
plt.close()
print("-> 图6已保存")

print("\n所有图表已保存至 output/ 目录")
