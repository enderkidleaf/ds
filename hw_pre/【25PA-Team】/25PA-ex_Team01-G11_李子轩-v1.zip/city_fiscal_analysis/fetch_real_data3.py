"""
从国家统计局真实下载数据 - 完整指标树
"""
import requests, json, time

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "X-Requested-With": "XMLHttpRequest",
    "Referer": "https://data.stats.gov.cn/easyquery.htm?cn=E0105"
})

session.get("https://data.stats.gov.cn/easyquery.htm?cn=E0105", timeout=30)

url = "https://data.stats.gov.cn/easyquery.htm"

# 获取完整指标树
print("获取完整指标树...")
params = {
    "m": "getTree",
    "dbcode": "csnd",
    "wds": "[]",
    "k1": str(int(time.time()*1000))
}
r = session.get(url, params=params, timeout=30)
print(f"状态: {r.status_code}")
print(f"响应: {r.text[:2000]}")

try:
    tree = r.json()
    print(f"\n指标树节点数: {len(tree)}")
    for node in tree[:20]:
        print(f"  {node.get('id', 'N/A')}: {node.get('name', 'N/A')}")
except Exception as e:
    print(f"解析失败: {e}")
