"""
从国家统计局真实下载数据
"""
import requests, json, time, os
import pandas as pd

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "X-Requested-With": "XMLHttpRequest",
    "Referer": "https://data.stats.gov.cn/easyquery.htm?cn=E0105"
})

print("访问国家统计局主页...")
try:
    r = session.get("https://data.stats.gov.cn/easyquery.htm?cn=E0105", timeout=30)
    print(f"主页状态: {r.status_code}")
except Exception as e:
    print(f"主页访问失败: {e}")

# 尝试获取数据库列表
url = "https://data.stats.gov.cn/easyquery.htm"
params = {
    "m": "getOtherWds",
    "id": "zb",
    "dbcode": "csnd",
    "rowcode": "reg",
    "colcode": "sj",
    "wds": "[]",
    "k1": str(int(time.time()*1000))
}

print("\n尝试获取城市数据库信息...")
try:
    r = session.get(url, params=params, timeout=30)
    print(f"API状态: {r.status_code}")
    print(f"响应长度: {len(r.text)}")
    print(f"响应内容前500字符: {r.text[:500]}")
    
    if r.status_code == 200:
        try:
            data = r.json()
            print(f"\n解析成功，返回码: {data.get('returncode')}")
            print(f"返回数据: {data.get('returndata', '')[:200]}")
        except:
            print("响应不是JSON格式")
except Exception as e:
    print(f"API请求失败: {e}")

print("\n尝试另一种API格式...")
# 尝试QueryData接口
params2 = {
    "m": "QueryData",
    "dbcode": "csnd",
    "rowcode": "reg",
    "colcode": "sj",
    "wds": '[]',
    "dfwds": '[{"wdcode":"zb","valuecode":"A050P01"}]',
    "k1": str(int(time.time()*1000))
}
try:
    r2 = session.get(url, params=params2, timeout=30)
    print(f"QueryData状态: {r2.status_code}")
    print(f"响应: {r2.text[:300]}")
except Exception as e:
    print(f"QueryData失败: {e}")
